using DataConverter;
using UnityEngine;

public class SkeletonExample : MonoBehaviour
{
    public float TrackingTimeout = 0.1f;
    public float TimeToReturnToDefault = 0.5f;
    public float SmoothTime = 0.1f;
    public KinectBinder Kinect;

    private Vector3 _position;
    private Vector3 _userInitialPosition;
    private GameObject[] _jointsGameObjects;

    public enum TrackingMode
    {
        UserFace,
        Gravity,
        ComputerControlled,
    }

    public TrackingMode CurrentMode { get; set; }

    void Awake()
    {
        GameObject j = GameObject.Find("Joint") as GameObject;
        GameObject kinectAvatar = GameObject.Find("KinectAvatar") as GameObject;
        _jointsGameObjects = new GameObject[(int)JointType.NumberOfJoints];

        for (int i = 0; i < (int)JointType.NumberOfJoints; i++)
        {
            GameObject joint = GameObject.Instantiate(j, j.transform.position, Quaternion.identity) as GameObject;
            joint.transform.parent = kinectAvatar.transform;
            _jointsGameObjects[i] = joint;
        }

        GameObject.Destroy(j);

    }

    void Start ()
    {
        _position = _userInitialPosition;
        Kinect.SkeletonDataReceived += ProcessSkeletonData;
        Kinect.LeftHandDataReceived += ProcessLeftHandData;
        Kinect.RightHandDataReceived += ProcessRightHandData;
    }

    void ProcessSkeletonData(JointData[] jointData)
    {
        GameObject head;
        for (int i = 0; i < (int)JointType.NumberOfJoints; i++)
        {
            float x = jointData[i].PositionX;
            float y = jointData[i].PositionY;
            float z = jointData[i].PositionZ;
            Vector3 jointPos = new Vector3(x,y,z);
            _jointsGameObjects[i].transform.localPosition = jointPos;

 
        }
    }

    void ProcessLeftHandData(int handStatus)
    {
        GameObject left = _jointsGameObjects[(int)JointType.HandLeft];
        
      
       
    }

    void ProcessRightHandData(int handStatus)
    {
        GameObject right = _jointsGameObjects[(int)JointType.HandRight];
        
    }


    private void InitializeUserData()
    {
        _userInitialPosition = _position;
    }

}
